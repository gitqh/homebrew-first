#!/bin/bash
echo "hello world firstly"
