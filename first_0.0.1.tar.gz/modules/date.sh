#!/bin/bash

date=`date`
echo $date
